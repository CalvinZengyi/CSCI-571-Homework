# svg-assets-cache

Exports the svg assets cache used by Angular Material
```
# Install
npm install svg-assets-cache

# Use
import svgAssetsCache from 'svg-assets-cache'

angular.module("module_name", svgAssetsCache);
```